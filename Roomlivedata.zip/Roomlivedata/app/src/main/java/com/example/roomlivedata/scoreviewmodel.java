package com.example.roomlivedata;

import androidx.lifecycle.ViewModel;

public class scoreviewmodel extends ViewModel {
    private Integer score;

    public Integer getScore() {
        if (score == null) {
            score = 0;
        }
        return score;
    }

    public void addscore() {
        if (score == null) {
            score = 0;
        }
        score += 1;
    }

    public void resetscore() {
        score = 0;
    }
}











